
const { createClient } = require("@supabase/supabase-js");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const db = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SECRET_KEY
);

const APP_URL = (process.env.APP_URL || "").replace(/\/$/, "");
const HANDLE = (process.env.INFINITEPAY_HANDLE || "").replace(/^\$/, "");
const API_KEY = process.env.INFINITEPAY_API_KEY || "";
const SESSION_SECRET = process.env.SESSION_SECRET;
const PRICE = 759;
const COOKIE = "omini_session";

function response(statusCode, data, extra = {}) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
      ...extra
    },
    body: JSON.stringify(data)
  };
}

function getBody(event) {
  try {
    return JSON.parse(event.body || "{}");
  } catch {
    return {};
  }
}

function getPath(event) {
  let path = event.path || "/";
  path = path.replace(/^\/\.netlify\/functions\/api/, "");
  path = path.replace(/^\/api/, "");
  return path || "/";
}

function getCookie(event) {
  const cookies = event.headers?.cookie || event.headers?.Cookie || "";
  const found = cookies.split(";").map(v => v.trim())
    .find(v => v.startsWith(COOKIE + "="));
  return found ? decodeURIComponent(found.split("=").slice(1).join("=")) : null;
}

function makeCookie(token) {
  return `${COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`;
}

function clearCookie() {
  return `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
}

function createSession(user) {
  return jwt.sign(user, SESSION_SECRET, { expiresIn: "7d" });
}

function currentUser(event) {
  try {
    const token = getCookie(event);
    if (!token) return null;
    return jwt.verify(token, SESSION_SECRET);
  } catch {
    return null;
  }
}

function cleanEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && value.length <= 190;
}

async function hasAccess(email) {
  const { data, error } = await db.from("access")
    .select("active").eq("email", email).maybeSingle();
  if (error) throw error;
  return data?.active === true;
}

async function checkPayment(orderNsu, transactionNsu, slug) {
  if (!HANDLE || !orderNsu || !transactionNsu || !slug) return false;

  const headers = { "Content-Type": "application/json" };
  if (API_KEY) headers["X-Api-Key"] = API_KEY;

  const result = await fetch(
    "https://api.checkout.infinitepay.io/payment_check",
    {
      method: "POST",
      headers,
      body: JSON.stringify({
        handle: HANDLE,
        order_nsu: String(orderNsu),
        transaction_nsu: String(transactionNsu),
        slug: String(slug)
      })
    }
  );

  if (!result.ok) return false;
  const data = await result.json();

  return data.success === true &&
    data.paid === true &&
    Number(data.amount) === PRICE;
}

async function verifyAndGrant(orderNsu, transactionNsu, slug) {
  const { data: order, error } = await db.from("orders")
    .select("*").eq("id", String(orderNsu || "")).maybeSingle();

  if (error || !order || Number(order.amount_cents) !== PRICE) return false;

  const paid = await checkPayment(orderNsu, transactionNsu, slug);
  if (!paid) return false;

  const { error: orderError } = await db.from("orders").update({
    status: "paid",
    transaction_nsu: String(transactionNsu),
    invoice_slug: String(slug),
    paid_at: new Date().toISOString()
  }).eq("id", order.id);

  if (orderError) throw orderError;

  const { error: accessError } = await db.from("access").upsert({
    email: order.email,
    active: true
  }, { onConflict: "email" });

  if (accessError) throw accessError;
  return true;
}

exports.handler = async (event) => {
  try {
    if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
      return response(500, { error: "Configuração de sessão inválida." });
    }

    const method = event.httpMethod;
    const path = getPath(event);
    const body = getBody(event);
    const user = currentUser(event);

    if (method === "GET" && path === "/config") {
      return response(200, {
        price: "7.59",
        priceLabel: "R$ 7,59",
        gateway: "InfinitePay",
        gatewayConfigured: !!HANDLE
      });
    }

    if (method === "POST" && path === "/checkout") {
      const email = cleanEmail(body.email);
      if (!validEmail(email)) {
        return response(400, { error: "Informe um e-mail válido." });
      }
      if (!HANDLE || !APP_URL) {
        return response(503, { error: "Checkout ainda não configurado." });
      }

      const orderId = require("crypto").randomUUID();
      const { error: insertError } = await db.from("orders").insert({
        id: orderId,
        email,
        amount_cents: PRICE,
        status: "pending"
      });

      if (insertError) throw insertError;

      const headers = { "Content-Type": "application/json" };
      if (API_KEY) headers["X-Api-Key"] = API_KEY;

      const result = await fetch("https://api.checkout.infinitepay.io/links", {
        method: "POST",
        headers,
        body: JSON.stringify({
          handle: HANDLE,
          order_nsu: orderId,
          redirect_url: `${APP_URL}/?payment=success`,
          webhook_url: `${APP_URL}/api/webhooks/infinitepay`,
          items: [{
            quantity: 1,
            price: PRICE,
            description: "Acesso OMINI MOTION"
          }],
          ...(API_KEY ? { options: { single_payment: true } } : {})
        })
      });

      const data = await result.json().catch(() => ({}));
      const checkoutUrl = data.url || data.checkout_url || data.link;

      let safeUrl = false;
      try {
        const parsed = new URL(checkoutUrl);
        safeUrl = parsed.protocol === "https:" &&
          parsed.hostname.endsWith("infinitepay.io");
      } catch {}

      if (!result.ok || !safeUrl) {
        await db.from("orders").update({ status: "error" }).eq("id", orderId);
        return response(502, { error: "Não foi possível gerar o pagamento na InfinitePay." });
      }

      return response(200, { checkoutUrl });
    }

    if (method === "POST" && path === "/webhooks/infinitepay") {
      const eventName = String(body.event || body.status || "paid").toLowerCase();

      if (["paid", "settled", "payment_approved"].includes(eventName)) {
        const ok = await verifyAndGrant(
          body.order_nsu,
          body.transaction_nsu,
          body.invoice_slug || body.slug
        );
        return response(ok ? 200 : 400, { received: ok });
      }

      return response(200, { received: true });
    }

    if (method === "GET" && path === "/payment/confirm") {
      const params = new URL(event.rawUrl).searchParams;
      const paid = await verifyAndGrant(
        params.get("order_nsu"),
        params.get("transaction_nsu"),
        params.get("slug")
      );
      return response(200, { paid });
    }

    if (method === "POST" && path === "/register") {
      const email = cleanEmail(body.email);
      const password = String(body.password || "");

      if (!validEmail(email) || password.length < 8 || password.length > 100) {
        return response(400, { error: "Use e-mail válido e senha de pelo menos 8 caracteres." });
      }

      if (!(await hasAccess(email))) {
        return response(403, { error: "Não encontramos pagamento aprovado para este e-mail." });
      }

      const password_hash = await bcrypt.hash(password, 12);
      const { error } = await db.from("users").insert({
        email, password_hash, role: "student"
      });

      if (error) {
        return response(409, { error: "Este e-mail já possui cadastro. Faça login." });
      }

      const token = createSession({ email, role: "student" });
      return response(200, { ok: true }, { "Set-Cookie": makeCookie(token) });
    }

    if (method === "POST" && path === "/login") {
      const email = cleanEmail(body.email);
      const password = String(body.password || "");

      if (!validEmail(email)) {
        return response(400, { error: "E-mail inválido." });
      }

      if (email === cleanEmail(process.env.ADMIN_EMAIL) &&
          process.env.ADMIN_PASSWORD &&
          password === process.env.ADMIN_PASSWORD) {
        const token = createSession({ email, role: "admin" });
        return response(200, { ok: true, role: "admin" },
          { "Set-Cookie": makeCookie(token) });
      }

      const { data: student, error } = await db.from("users")
        .select("*").eq("email", email).maybeSingle();

      if (error) throw error;
      if (!student || !(await bcrypt.compare(password, student.password_hash))) {
        return response(401, { error: "E-mail ou senha incorretos." });
      }

      if (!(await hasAccess(email))) {
        return response(403, { error: "Seu acesso não está ativo." });
      }

      const token = createSession({ email, role: student.role });
      return response(200, { ok: true, role: student.role },
        { "Set-Cookie": makeCookie(token) });
    }

    if (method === "POST" && path === "/logout") {
      return response(200, { ok: true }, { "Set-Cookie": clearCookie() });
    }

    if (method === "GET" && path === "/me") {
      return response(200, {
        user: user ? { email: user.email, role: user.role } : null
      });
    }

    if (method === "GET" && path === "/lessons") {
      if (!user) return response(401, { error: "Faça login para continuar." });
      if (user.role !== "admin" && !(await hasAccess(user.email))) {
        return response(403, { error: "Acesso não ativo." });
      }

      const { data, error } = await db.from("lessons")
        .select("id,title,description,video_url,position")
        .eq("published", true).order("position");

      if (error) throw error;
      return response(200, {
        lessons: (data || []).map(item => ({
          ...item, videoUrl: item.video_url
        }))
      });
    }

    if (path.startsWith("/admin/")) {
      if (!user || user.role !== "admin") {
        return response(403, { error: "Acesso restrito ao administrador." });
      }

      if (method === "GET" && path === "/admin/overview") {
        const [access, orders, lessons] = await Promise.all([
          db.from("access").select("email").eq("active", true),
          db.from("orders").select("*").order("created_at", { ascending: false }).limit(30),
          db.from("lessons").select("*").order("position")
        ]);

        if (access.error || orders.error || lessons.error) throw new Error("Erro ao consultar painel.");

        const allOrders = orders.data || [];
        const paid = allOrders.filter(o => o.status === "paid");
        const pending = allOrders.filter(o => o.status === "pending");
        const revenue = paid.reduce((sum, o) => sum + Number(o.amount_cents), 0);

        return response(200, {
          stats: {
            students: access.data.length,
            paid: paid.length,
            pending: pending.length,
            revenue: (revenue / 100).toFixed(2)
          },
          orders: allOrders.map(o => ({
            id: o.id, email: o.email, status: o.status,
            amountCents: o.amount_cents, createdAt: o.created_at
          })),
          lessons: lessons.data
        });
      }

      if (method === "POST" && path === "/admin/lessons") {
        const title = String(body.title || "").trim().slice(0, 120);
        const description = String(body.description || "").trim().slice(0, 500);
        const video_url = String(body.videoUrl || "").trim().slice(0, 500);

        if (!title) return response(400, { error: "Informe o título da aula." });

        if (video_url && !/^https:\/\/(www\.)?(youtube\.com|youtu\.be|player\.vimeo\.com)\//.test(video_url)) {
          return response(400, { error: "Use um link HTTPS do YouTube ou Vimeo." });
        }

        const { data, error } = await db.from("lessons").insert({
          title, description, video_url, position: Date.now()
        }).select("id").single();

        if (error) throw error;
        return response(200, { ok: true, id: data.id });
      }

      if (method === "POST" && path === "/admin/access") {
        const email = cleanEmail(body.email);
        if (!validEmail(email)) return response(400, { error: "E-mail inválido." });

        const { error } = await db.from("access").upsert({
          email, active: true
        }, { onConflict: "email" });

        if (error) throw error;
        return response(200, { ok: true });
      }
    }

    return response(404, { error: "Rota não encontrada." });
  } catch (error) {
    console.error("OMINI API error:", error);
    return response(500, { error: "Erro interno. Tente novamente." });
  }
};
