require("dotenv").config();

const express = require("express");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const APP_URL = (process.env.APP_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const PRICE_CENTS = Number(process.env.PRODUCT_PRICE_CENTS || 759);
const PRICE = PRICE_CENTS / 100;
const INFINITEPAY_HANDLE = String(process.env.INFINITEPAY_HANDLE || "").trim().replace(/^\$/, "");
const INFINITEPAY_API_KEY = String(process.env.INFINITEPAY_API_KEY || "").trim();

if (process.env.NODE_ENV === "production" && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error("SESSION_SECRET precisa ter pelo menos 32 caracteres em produção.");
}
if (!process.env.ADMIN_PASSWORD) {
  console.warn("ATENÇÃO: defina ADMIN_PASSWORD antes de usar o painel administrativo.");
}

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "omini-motion.sqlite"));
db.pragma("journal_mode = WAL");
const orderColumns = db.prepare("PRAGMA table_info(orders)").all().map(column => column.name);
if (!orderColumns.includes("invoice_slug")) db.exec("ALTER TABLE orders ADD COLUMN invoice_slug TEXT");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    mp_payment_id TEXT,
    invoice_slug TEXT,
    amount_cents INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    paid_at TEXT
  );
  CREATE TABLE IF NOT EXISTS access (
    email TEXT PRIMARY KEY,
    active INTEGER NOT NULL DEFAULT 1,
    granted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS lessons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    video_url TEXT NOT NULL DEFAULT '',
    position INTEGER NOT NULL DEFAULT 0,
    published INTEGER NOT NULL DEFAULT 1
  );
`);

const seed = db.prepare("SELECT COUNT(*) AS n FROM lessons").get();
if (!seed.n) {
  const insert = db.prepare("INSERT INTO lessons (title, description, video_url, position) VALUES (?, ?, ?, ?)");
  insert.run("Comece por aqui: visão geral", "Entenda como funciona o método e o que você vai aprender.", "", 1);
  insert.run("Criando seu primeiro vídeo com IA", "Do roteiro à edição: fluxo básico para produzir um vídeo.", "", 2);
  insert.run("Prompts que economizam tempo", "Como orientar ferramentas de IA para chegar ao resultado desejado.", "", 3);
}

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "https:"],
      frameSrc: ["'self'", "https://www.youtube.com", "https://player.vimeo.com"],
      connectSrc: ["'self'"]
    }
  }
}));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: false, limit: "30kb" }));
app.set("trust proxy", 1);

app.use(session({
  store: new SQLiteStoreFactory({ db: "sessions.sqlite", dir: dataDir, concurrentDB: true }),
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret-please",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false });
const checkoutLimiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });

function cleanEmail(value) {
  return String(value || "").trim().toLowerCase();
}
function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && value.length <= 190;
}
function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Faça login para continuar." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== "admin") {
    return res.status(403).json({ error: "Acesso restrito ao administrador." });
  }
  next();
}
function hasAccess(email) {
  return !!db.prepare("SELECT active FROM access WHERE email = ? AND active = 1").get(email);
}
function publicUser(user) {
  return { email: user.email, role: user.role };
}
async function checkInfinitePayPayment({ orderNsu, transactionNsu, slug }) {
  if (!INFINITEPAY_HANDLE || !orderNsu || !transactionNsu || !slug) return null;
  const headers = { "Content-Type": "application/json" };
  if (INFINITEPAY_API_KEY) headers["X-Api-Key"] = INFINITEPAY_API_KEY;
  const response = await fetch("https://api.checkout.infinitepay.io/payment_check", {
    method: "POST",
    headers,
    body: JSON.stringify({
      handle: INFINITEPAY_HANDLE,
      order_nsu: String(orderNsu),
      transaction_nsu: String(transactionNsu),
      slug: String(slug)
    })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`InfinitePay payment_check respondeu ${response.status}`);
  return result;
}

function applyConfirmedPayment(order, transactionNsu, slug) {
  const tx = db.transaction(() => {
    db.prepare(`UPDATE orders SET status = 'paid', mp_payment_id = ?, invoice_slug = ?, paid_at = COALESCE(paid_at, CURRENT_TIMESTAMP) WHERE id = ?`)
      .run(String(transactionNsu), String(slug), order.id);
    db.prepare("INSERT INTO access (email, active) VALUES (?, 1) ON CONFLICT(email) DO UPDATE SET active = 1")
      .run(order.email);
  });
  tx();
}

async function verifyAndGrantAccess({ orderNsu, transactionNsu, slug }) {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(String(orderNsu || ""));
  if (!order || order.amount_cents !== PRICE_CENTS) return false;
  const check = await checkInfinitePayPayment({ orderNsu, transactionNsu, slug });
  if (!check || check.success !== true || check.paid !== true || Number(check.amount) !== order.amount_cents) return false;
  applyConfirmedPayment(order, transactionNsu, slug);
  return true;
}

app.get("/api/config", (req, res) => {
  res.json({
    price: PRICE.toFixed(2),
    priceLabel: PRICE.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }),
    gatewayConfigured: !!INFINITEPAY_HANDLE,
    gateway: "InfinitePay"
  });
});

app.post("/api/checkout", checkoutLimiter, async (req, res) => {
  try {
    const email = cleanEmail(req.body.email);
    if (!validEmail(email)) return res.status(400).json({ error: "Informe um e-mail válido." });
    if (!INFINITEPAY_HANDLE) return res.status(503).json({ error: "A InfinitePay ainda não foi configurada. O administrador precisa preencher INFINITEPAY_HANDLE no ambiente do servidor." });

    const orderId = crypto.randomUUID();
    db.prepare("INSERT INTO orders (id, email, amount_cents) VALUES (?, ?, ?)").run(orderId, email, PRICE_CENTS);

    const headers = { "Content-Type": "application/json" };
    if (INFINITEPAY_API_KEY) headers["X-Api-Key"] = INFINITEPAY_API_KEY;
    const payload = {
      handle: INFINITEPAY_HANDLE,
      order_nsu: orderId,
      redirect_url: `${APP_URL}/?payment=success`,
      webhook_url: `${APP_URL}/api/webhooks/infinitepay`,
      items: [{ quantity: 1, price: PRICE_CENTS, description: "Acesso OMINI MOTION" }]
    };
    // single_payment é uma opção avançada e exige API Key na InfinitePay.
    if (INFINITEPAY_API_KEY) payload.options = { single_payment: true };

    const response = await fetch("https://api.checkout.infinitepay.io/links", {
      method: "POST", headers, body: JSON.stringify(payload)
    });
    const result = await response.json().catch(() => ({}));
    const checkoutUrl = result.url || result.checkout_url || result.link;
    let safeCheckoutUrl = false;
    try {
      const parsed = new URL(checkoutUrl);
      safeCheckoutUrl = parsed.protocol === "https:" && parsed.hostname.endsWith("infinitepay.io");
    } catch {}
    if (!response.ok || !safeCheckoutUrl) {
      console.error("InfinitePay link error:", { status: response.status, result });
      db.prepare("UPDATE orders SET status = 'error' WHERE id = ?").run(orderId);
      return res.status(502).json({ error: "A InfinitePay não conseguiu gerar o link. Confira sua InfiniteTag e se o Checkout Integrado está habilitado." });
    }
    res.json({ checkoutUrl });
  } catch (error) {
    console.error("Checkout error:", error);
    res.status(500).json({ error: "Erro ao iniciar o pagamento. Tente novamente." });
  }
});

// A InfinitePay não assina os webhooks: cada evento é conferido na payment_check.
app.post("/api/webhooks/infinitepay", async (req, res) => {
  try {
    const body = req.body || {};
    const event = String(body.event || body.status || "paid").toLowerCase();
    const orderNsu = body.order_nsu;
    const transactionNsu = body.transaction_nsu;
    const slug = body.invoice_slug || body.slug;
    if (event === "refunded" || event === "refund") {
      // A InfinitePay não assina webhooks e a API documentada não oferece consulta
      // de estorno. Não revogue acesso com base em um aviso que pode ser falsificado.
      console.warn("InfinitePay refund notice received; review the refund in the merchant dashboard.", { orderNsu });
      return res.sendStatus(200);
    }
    if (event === "paid" || event === "settled" || event === "payment_approved") {
      const verified = await verifyAndGrantAccess({ orderNsu, transactionNsu, slug });
      return res.sendStatus(verified ? 200 : 400);
    }
    return res.sendStatus(200);
  } catch (error) {
    console.error("InfinitePay webhook error:", error);
    return res.sendStatus(500);
  }
});

// O retorno do navegador também é validado na API; voltar à página não libera acesso sozinho.
app.get("/api/payment/confirm", async (req, res) => {
  try {
    const verified = await verifyAndGrantAccess({
      orderNsu: req.query.order_nsu,
      transactionNsu: req.query.transaction_nsu,
      slug: req.query.slug
    });
    res.json({ paid: verified });
  } catch (error) {
    console.error("Payment return verification error:", error);
    res.status(502).json({ paid: false, error: "Não foi possível confirmar agora. Aguarde a confirmação automática." });
  }
});

app.post("/api/register", authLimiter, async (req, res) => {
  const email = cleanEmail(req.body.email);
  const password = String(req.body.password || "");
  if (!validEmail(email) || password.length < 8 || password.length > 100) {
    return res.status(400).json({ error: "Use um e-mail válido e uma senha com pelo menos 8 caracteres." });
  }
  if (!hasAccess(email)) return res.status(403).json({ error: "Ainda não encontramos um pagamento aprovado para este e-mail." });
  const hash = await bcrypt.hash(password, 12);
  try {
    db.prepare("INSERT INTO users (email, password_hash) VALUES (?, ?)").run(email, hash);
    req.session.user = { email, role: "student" };
    res.json({ ok: true });
  } catch {
    res.status(409).json({ error: "Este e-mail já possui cadastro. Faça login." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  const email = cleanEmail(req.body.email);
  const password = String(req.body.password || "");
  if (!validEmail(email)) return res.status(400).json({ error: "E-mail inválido." });

  if (email === cleanEmail(process.env.ADMIN_EMAIL) && process.env.ADMIN_PASSWORD &&
      password === process.env.ADMIN_PASSWORD) {
    req.session.user = { email, role: "admin" };
    return res.json({ ok: true, role: "admin" });
  }

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: "E-mail ou senha incorretos." });
  }
  if (!hasAccess(email)) return res.status(403).json({ error: "Seu acesso não está ativo. Entre em contato com o suporte." });
  req.session.user = publicUser(user);
  res.json({ ok: true, role: user.role });
});

app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.get("/api/lessons", requireLogin, (req, res) => {
  if (req.session.user.role !== "admin" && !hasAccess(req.session.user.email)) {
    return res.status(403).json({ error: "Acesso não ativo." });
  }
  const lessons = db.prepare("SELECT id, title, description, video_url AS videoUrl, position FROM lessons WHERE published = 1 ORDER BY position, id").all();
  res.json({ lessons });
});

app.get("/api/admin/overview", requireAdmin, (req, res) => {
  const students = db.prepare("SELECT COUNT(*) AS n FROM access WHERE active = 1").get().n;
  const paid = db.prepare("SELECT COUNT(*) AS n FROM orders WHERE status = 'paid'").get().n;
  const pending = db.prepare("SELECT COUNT(*) AS n FROM orders WHERE status = 'pending'").get().n;
  const revenue = db.prepare("SELECT COALESCE(SUM(amount_cents), 0) AS cents FROM orders WHERE status = 'paid'").get().cents;
  const orders = db.prepare("SELECT id, email, status, amount_cents AS amountCents, created_at AS createdAt FROM orders ORDER BY created_at DESC LIMIT 30").all();
  const lessons = db.prepare("SELECT id, title, description, video_url AS videoUrl, position, published FROM lessons ORDER BY position, id").all();
  res.json({ stats: { students, paid, pending, revenue: (revenue / 100).toFixed(2) }, orders, lessons });
});

app.post("/api/admin/lessons", requireAdmin, (req, res) => {
  const title = String(req.body.title || "").trim().slice(0, 120);
  const description = String(req.body.description || "").trim().slice(0, 500);
  const videoUrl = String(req.body.videoUrl || "").trim().slice(0, 500);
  if (!title) return res.status(400).json({ error: "Informe o título da aula." });
  if (videoUrl && !/^https:\/\/(www\.)?(youtube\.com|youtu\.be|player\.vimeo\.com)\//.test(videoUrl)) {
    return res.status(400).json({ error: "Use um link HTTPS do YouTube ou Vimeo." });
  }
  const info = db.prepare("INSERT INTO lessons (title, description, video_url, position) VALUES (?, ?, ?, ?)").run(title, description, videoUrl, Date.now());
  res.json({ ok: true, id: info.lastInsertRowid });
});

app.patch("/api/admin/lessons/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const published = req.body.published ? 1 : 0;
  db.prepare("UPDATE lessons SET published = ? WHERE id = ?").run(published, id);
  res.json({ ok: true });
});

app.post("/api/admin/access", requireAdmin, (req, res) => {
  const email = cleanEmail(req.body.email);
  if (!validEmail(email)) return res.status(400).json({ error: "E-mail inválido." });
  db.prepare("INSERT INTO access (email, active) VALUES (?, 1) ON CONFLICT(email) DO UPDATE SET active = 1").run(email);
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`OMINI MOTION disponível em ${APP_URL}`));
