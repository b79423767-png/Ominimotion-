const $ = (s) => document.querySelector(s);
let authMode = "login";
const money = (value) => Number(value).toLocaleString("pt-BR", {style:"currency",currency:"BRL"});

async function api(url, options={}) {
  const response = await fetch(url, {
    credentials:"same-origin",
    headers: {"Content-Type":"application/json", ...(options.headers||{})},
    ...options
  });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || "Não foi possível concluir a solicitação.");
  return data;
}
function showMessage(selector, message, isError=false) {
  const el = $(selector); if (!el) return;
  el.textContent = message; el.style.color = isError ? "#ff9a9a" : "var(--cyan)";
}
function showHome() {
  $("#home").classList.remove("hidden");
  $("#member-view").classList.add("hidden");
  $("#admin-view").classList.add("hidden");
}
function openAuth(mode="login") {
  authMode=mode;
  $("#auth-modal").classList.remove("hidden");
  document.querySelectorAll("[data-tab]").forEach(b=>b.classList.toggle("active",b.dataset.tab===mode));
  $("#auth-title").textContent=mode==="login"?"Entre na sua conta.":"Crie sua conta.";
  $("#auth-description").textContent=mode==="login"?"Acesse suas aulas exclusivas.":"Use o mesmo e-mail informado na compra aprovada.";
  $("#auth-submit").textContent=mode==="login"?"Entrar":"Criar conta";
  $("#auth-form").reset(); showMessage("#auth-message","");
}
function closeAuth(){ $("#auth-modal").classList.add("hidden"); }
async function refreshView() {
  try {
    const {user}=await api("/api/me");
    if (!user) { showHome(); return; }
    $("#home").classList.add("hidden");
    if(user.role==="admin"){ $("#admin-view").classList.remove("hidden"); $("#member-view").classList.add("hidden"); await loadAdmin(); }
    else { $("#member-view").classList.remove("hidden"); $("#admin-view").classList.add("hidden"); await loadLessons(); }
  } catch { showHome(); }
}
async function loadLessons(){
  const {lessons}=await api("/api/lessons");
  $("#lesson-list").innerHTML=lessons.map((lesson,i)=>{
    let video="";
    if(lesson.videoUrl){
      let url=lesson.videoUrl;
      const yt=url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
      const vm=url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
      if(yt) video=`<iframe src="https://www.youtube-nocookie.com/embed/${yt[1]}" allowfullscreen loading="lazy"></iframe>`;
      else if(vm) video=`<iframe src="https://player.vimeo.com/video/${vm[1]}" allowfullscreen loading="lazy"></iframe>`;
    }
    return `<article class="lesson"><div class="eyebrow">AULA ${String(i+1).padStart(2,"0")}</div><h3>${escapeHtml(lesson.title)}</h3><p>${escapeHtml(lesson.description||"")}</p>${video}</article>`;
  }).join("") || "<p>As aulas serão adicionadas em breve.</p>";
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function loadAdmin(){
  const data=await api("/api/admin/overview");
  const stats=[["Alunos ativos",data.stats.students],["Vendas aprovadas",data.stats.paid],["Pedidos pendentes",data.stats.pending],["Faturamento",money(data.stats.revenue)]];
  $("#admin-stats").innerHTML=stats.map(([k,v])=>`<div class="stat"><span>${k}</span><b>${v}</b></div>`).join("");
  $("#orders-table").innerHTML=`<div class="table-wrap"><table><thead><tr><th>E-mail</th><th>Status</th><th>Valor</th><th>Data</th></tr></thead><tbody>${data.orders.map(o=>`<tr><td>${escapeHtml(o.email)}</td><td class="status">${escapeHtml(o.status)}</td><td>${money(o.amountCents/100)}</td><td>${escapeHtml(o.createdAt)}</td></tr>`).join("")||"<tr><td colspan='4'>Nenhum pedido ainda.</td></tr>"}</tbody></table></div>`;
}
$("#buy-button").addEventListener("click",async()=>{
  const email=$("#buy-email").value.trim();
  if(!email){showMessage("#buy-message","Digite seu e-mail para continuar.",true);return;}
  $("#buy-button").disabled=true;$("#buy-button").textContent="Preparando pagamento...";
  try{const {checkoutUrl}=await api("/api/checkout",{method:"POST",body:JSON.stringify({email})});window.location.href=checkoutUrl;}
  catch(e){showMessage("#buy-message",e.message,true);}
  finally{$("#buy-button").disabled=false;$("#buy-button").innerHTML='Garantir meu acesso <span>↗</span>';}
});
document.querySelectorAll("[data-open-login]").forEach(b=>b.addEventListener("click",()=>openAuth("login")));
$("#close-modal").addEventListener("click",closeAuth);
$("#auth-modal").addEventListener("click",e=>{if(e.target.id==="auth-modal")closeAuth();});
document.querySelectorAll("[data-tab]").forEach(b=>b.addEventListener("click",()=>openAuth(b.dataset.tab)));
$("#auth-form").addEventListener("submit",async e=>{
  e.preventDefault();const form=new FormData(e.currentTarget);
  const endpoint=authMode==="login"?"/api/login":"/api/register";
  try{await api(endpoint,{method:"POST",body:JSON.stringify({email:form.get("email"),password:form.get("password")})});closeAuth();await refreshView();}
  catch(err){showMessage("#auth-message",err.message,true);}
});
async function logout(){await api("/api/logout",{method:"POST",body:"{}"});showHome();}
$("#logout").addEventListener("click",logout);$("#admin-logout").addEventListener("click",logout);
$("#lesson-form").addEventListener("submit",async e=>{
  e.preventDefault();const f=new FormData(e.currentTarget);
  try{await api("/api/admin/lessons",{method:"POST",body:JSON.stringify({title:f.get("title"),description:f.get("description"),videoUrl:f.get("videoUrl")})});e.currentTarget.reset();showMessage("#lesson-message","Aula adicionada.");await loadAdmin();}
  catch(err){showMessage("#lesson-message",err.message,true);}
});
$("#access-form").addEventListener("submit",async e=>{
  e.preventDefault();const f=new FormData(e.currentTarget);
  try{await api("/api/admin/access",{method:"POST",body:JSON.stringify({email:f.get("email")})});e.currentTarget.reset();showMessage("#access-message","Acesso liberado. O aluno já pode criar a conta.");await loadAdmin();}
  catch(err){showMessage("#access-message",err.message,true);}
});
$("#year").textContent=new Date().getFullYear();
(async()=>{
  try{const c=await api("/api/config");$("#price").textContent=c.priceLabel;}
  catch{}
  const params=new URLSearchParams(location.search);
  if(params.get("payment")==="success"){
    showMessage("#buy-message","Conferindo seu pagamento com a InfinitePay...");
    const order_nsu=params.get("order_nsu"), transaction_nsu=params.get("transaction_nsu"), slug=params.get("slug");
    if(order_nsu && transaction_nsu && slug){
      try{
        const result=await api(`/api/payment/confirm?${new URLSearchParams({order_nsu,transaction_nsu,slug})}`);
        showMessage("#buy-message",result.paid?"Pagamento confirmado! Agora você já pode criar sua conta usando o mesmo e-mail da compra.":"Ainda não conseguimos confirmar o pagamento. Aguarde alguns instantes e tente entrar novamente.",!result.paid);
      }catch{showMessage("#buy-message","Pagamento recebido para conferência. O acesso será liberado assim que a InfinitePay confirmar.");}
    }else showMessage("#buy-message","Retorno recebido. A confirmação automática está em andamento; o acesso só será liberado após validação da InfinitePay.");
  }
  if(params.get("payment")==="pending")showMessage("#buy-message","Seu pagamento está pendente. O acesso será liberado após a aprovação da InfinitePay.");
  if(params.get("payment")==="failure")showMessage("#buy-message","O pagamento não foi concluído. Você pode tentar novamente.");
  await refreshView();
})();
